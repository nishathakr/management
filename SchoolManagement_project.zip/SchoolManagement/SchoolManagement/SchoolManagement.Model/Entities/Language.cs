﻿using System.ComponentModel.DataAnnotations;

namespace SchoolManagement.Model.Entities
{
    public class Language : BaseEntity
    {
    }
}
